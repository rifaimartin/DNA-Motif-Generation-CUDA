#ifndef MOTIF_GENERATOR_H
#define MOTIF_GENERATOR_H

#include <cuda_runtime.h>
#include <curand_kernel.h>
#include <vector>
#include <string>
#include <memory>

// Nucleotide encoding: A=0, T=1, C=2, G=3
#define NUCLEOTIDE_COUNT 4
#define A_IDX 0
#define T_IDX 1  
#define C_IDX 2
#define G_IDX 3

// Constraint types
enum ConstraintType {
    GC_CONTENT = 0,
    HOMOPOLYMER = 1, 
    HAIRPIN = 2,
    NO_KEY_IN_PAYLOAD = 3,
    CONSTRAINT_COUNT = 4
};

// Device configuration
struct DeviceConfig {
    int max_threads_per_block;
    int max_blocks_per_grid;
    int shared_memory_size;
    int warp_size;
};

// Biological constraints parameters
struct BiologicalConstraints {
    int payload_size;
    int payload_num;
    int max_hom;           // Maximum homopolymer length
    int max_hairpin;       // Maximum hairpin stem size
    int loop_size_min;     // Minimum loop size for hairpin
    int loop_size_max;     // Maximum loop size for hairpin
    float min_gc;          // Minimum GC content (0-100)
    float max_gc;          // Maximum GC content (0-100)
    int key_size;
    int key_num;
};

// Hyperparameters for reward shaping
struct Hyperparameters {
    float shapes[CONSTRAINT_COUNT];    // Shape parameters for each constraint
    float weights[CONSTRAINT_COUNT];   // Weight parameters for each constraint
};

// GPU memory structure for motif generation
struct MotifGenerationData {
    // Device pointers
    unsigned char* d_sequences;        // Generated sequences [batch_size * max_length]
    float* d_rewards;                  // Reward values [batch_size * NUCLEOTIDE_COUNT]
    float* d_probabilities;            // Probability distributions [batch_size * NUCLEOTIDE_COUNT]
    curandState* d_rand_states;        // Random states [batch_size]
    bool* d_valid_flags;               // Validation flags [batch_size]
    int* d_sequence_lengths;           // Current sequence lengths [batch_size]
    
    // Host pointers
    std::vector<std::string> h_sequences;
    std::vector<bool> h_valid_flags;
    
    // Memory management
    size_t batch_size;
    size_t max_sequence_length;
    bool is_allocated;
};

class CudaMotifGenerator {
private:
    BiologicalConstraints constraints_;
    Hyperparameters hyperparams_;
    DeviceConfig device_config_;
    MotifGenerationData gpu_data_;
    
    // CUDA streams for asynchronous operations
    cudaStream_t computation_stream_;
    cudaStream_t memory_stream_;
    
    // Keys storage (from baseline Python implementation)
    std::vector<std::string> keys_;
    std::vector<std::vector<unsigned char>> encoded_keys_;

public:
    // Constructor & Destructor
    CudaMotifGenerator(const BiologicalConstraints& constraints,
                      const Hyperparameters& hyperparams);
    ~CudaMotifGenerator();
    
    // Initialization
    bool initialize_device();
    bool allocate_gpu_memory(size_t batch_size, size_t max_length);
    void free_gpu_memory();
    
    // Key management
    bool add_keys(const std::vector<std::string>& keys);
    
    // Main generation functions
    std::vector<std::string> generate_payloads_batch(size_t batch_size);
    std::string generate_single_payload();
    
    // Motif assembly
    std::vector<std::string> get_motifs(const std::vector<std::string>& payloads);
    
    // Performance monitoring
    struct PerformanceMetrics {
        float generation_time_ms;
        float constraint_check_time_ms;
        float memory_transfer_time_ms;
        size_t valid_sequences_generated;
        size_t total_sequences_attempted;
        float success_rate;
    };
    
    PerformanceMetrics get_performance_metrics() const;
    void reset_performance_metrics();
    
    // Utility functions
    static std::vector<unsigned char> encode_sequence(const std::string& sequence);
    static std::string decode_sequence(const std::vector<unsigned char>& encoded);
    static void print_device_info();

private:
    // Internal helper functions
    bool setup_cuda_streams();
    void cleanup_cuda_streams();
    bool initialize_random_states(size_t batch_size);
    
    // Performance tracking
    mutable PerformanceMetrics perf_metrics_;
    cudaEvent_t start_event_, stop_event_;
};

// CUDA kernel declarations (implemented in separate .cu files)
extern "C" {
    void launch_mdp_generation_kernel(
        unsigned char* d_sequences,
        float* d_rewards,
        float* d_probabilities,
        curandState* d_rand_states,
        bool* d_valid_flags,
        int* d_sequence_lengths,
        const BiologicalConstraints* d_constraints,
        const Hyperparameters* d_hyperparams,
        const unsigned char* d_keys,
        int batch_size,
        int max_length,
        cudaStream_t stream
    );
    
    void launch_constraint_validation_kernel(
        const unsigned char* d_sequences,
        const int* d_sequence_lengths,
        bool* d_valid_flags,
        const BiologicalConstraints* d_constraints,
        const unsigned char* d_keys,
        int batch_size,
        cudaStream_t stream
    );
    
    void launch_reward_calculation_kernel(
        const unsigned char* d_sequences,
        const int* d_sequence_lengths,
        float* d_rewards,
        const BiologicalConstraints* d_constraints,
        const Hyperparameters* d_hyperparams,
        const unsigned char* d_keys,
        int batch_size,
        int current_position,
        cudaStream_t stream
    );
}

#endif // MOTIF_GENERATOR_H