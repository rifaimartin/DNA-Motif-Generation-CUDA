#include "motif_generator.h"
#include <iostream>
#include <chrono>
#include <algorithm>
#include <random>

// External kernel launch functions
extern "C" {
    void launch_init_random_states(
        curandState* d_rand_states,
        unsigned long seed,
        int batch_size,
        cudaStream_t stream
    );
}

CudaMotifGenerator::CudaMotifGenerator(
    const BiologicalConstraints& constraints,
    const Hyperparameters& hyperparams
) : constraints_(constraints), hyperparams_(hyperparams) {
    
    // Initialize performance metrics
    memset(&perf_metrics_, 0, sizeof(PerformanceMetrics));
    
    // Initialize GPU data structure
    gpu_data_.is_allocated = false;
    gpu_data_.batch_size = 0;
    gpu_data_.max_sequence_length = 0;
    
    // Initialize CUDA events
    cudaEventCreate(&start_event_);
    cudaEventCreate(&stop_event_);
    
    // Initialize device
    if (!initialize_device()) {
        throw std::runtime_error("Failed to initialize CUDA device");
    }
}

CudaMotifGenerator::~CudaMotifGenerator() {
    free_gpu_memory();
    cleanup_cuda_streams();
    
    cudaEventDestroy(start_event_);
    cudaEventDestroy(stop_event_);
}

bool CudaMotifGenerator::initialize_device() {
    // Get device properties
    int device_count;
    cudaGetDeviceCount(&device_count);
    
    if (device_count == 0) {
        std::cerr << "No CUDA-capable devices found!" << std::endl;
        return false;
    }
    
    // Use first available device
    cudaSetDevice(0);
    
    cudaDeviceProp prop;
    cudaGetDeviceProperties(&prop, 0);
    
    // Store device configuration
    device_config_.max_threads_per_block = prop.maxThreadsPerBlock;
    device_config_.max_blocks_per_grid = prop.maxGridSize[0];
    device_config_.shared_memory_size = prop.sharedMemPerBlock;
    device_config_.warp_size = prop.warpSize;
    
    std::cout << "Using device: " << prop.name << std::endl;
    std::cout << "Max threads per block: " << device_config_.max_threads_per_block << std::endl;
    std::cout << "Max blocks per grid: " << device_config_.max_blocks_per_grid << std::endl;
    
    return setup_cuda_streams();
}

bool CudaMotifGenerator::setup_cuda_streams() {
    cudaError_t err1 = cudaStreamCreate(&computation_stream_);
    cudaError_t err2 = cudaStreamCreate(&memory_stream_);
    
    if (err1 != cudaSuccess || err2 != cudaSuccess) {
        std::cerr << "Failed to create CUDA streams" << std::endl;
        return false;
    }
    
    return true;
}

void CudaMotifGenerator::cleanup_cuda_streams() {
    if (computation_stream_) {
        cudaStreamDestroy(computation_stream_);
    }
    if (memory_stream_) {
        cudaStreamDestroy(memory_stream_);
    }
}

bool CudaMotifGenerator::allocate_gpu_memory(size_t batch_size, size_t max_length) {
    if (gpu_data_.is_allocated) {
        free_gpu_memory();
    }
    
    gpu_data_.batch_size = batch_size;
    gpu_data_.max_sequence_length = max_length;
    
    // Calculate memory sizes
    size_t sequences_size = batch_size * max_length * sizeof(unsigned char);
    size_t rewards_size = batch_size * NUCLEOTIDE_COUNT * sizeof(float);
    size_t probabilities_size = batch_size * NUCLEOTIDE_COUNT * sizeof(float);
    size_t rand_states_size = batch_size * sizeof(curandState);
    size_t valid_flags_size = batch_size * sizeof(unsigned char);  // Changed to unsigned char
    size_t lengths_size = batch_size * sizeof(int);
    
    // Allocate device memory
    cudaError_t err;
    
    err = cudaMalloc(&gpu_data_.d_sequences, sequences_size);
    if (err != cudaSuccess) goto cleanup;
    
    err = cudaMalloc(&gpu_data_.d_rewards, rewards_size);
    if (err != cudaSuccess) goto cleanup;
    
    err = cudaMalloc(&gpu_data_.d_probabilities, probabilities_size);
    if (err != cudaSuccess) goto cleanup;
    
    err = cudaMalloc(&gpu_data_.d_rand_states, rand_states_size);
    if (err != cudaSuccess) goto cleanup;
    
    err = cudaMalloc(&gpu_data_.d_valid_flags, valid_flags_size);
    if (err != cudaSuccess) goto cleanup;
    
    err = cudaMalloc(&gpu_data_.d_sequence_lengths, lengths_size);
    if (err != cudaSuccess) goto cleanup;
    
    // Initialize host vectors
    gpu_data_.h_sequences.resize(batch_size);
    gpu_data_.h_valid_flags.resize(batch_size);
    
    gpu_data_.is_allocated = true;
    
    // Initialize random states
    return initialize_random_states(batch_size);
    
cleanup:
    std::cerr << "Failed to allocate GPU memory: " << cudaGetErrorString(err) << std::endl;
    free_gpu_memory();
    return false;
}

void CudaMotifGenerator::free_gpu_memory() {
    if (!gpu_data_.is_allocated) return;
    
    if (gpu_data_.d_sequences) cudaFree(gpu_data_.d_sequences);
    if (gpu_data_.d_rewards) cudaFree(gpu_data_.d_rewards);
    if (gpu_data_.d_probabilities) cudaFree(gpu_data_.d_probabilities);
    if (gpu_data_.d_rand_states) cudaFree(gpu_data_.d_rand_states);
    if (gpu_data_.d_valid_flags) cudaFree(gpu_data_.d_valid_flags);
    if (gpu_data_.d_sequence_lengths) cudaFree(gpu_data_.d_sequence_lengths);
    
    gpu_data_.is_allocated = false;
}

bool CudaMotifGenerator::initialize_random_states(size_t batch_size) {
    // Generate random seed
    auto now = std::chrono::high_resolution_clock::now();
    auto seed = std::chrono::duration_cast<std::chrono::microseconds>(
        now.time_since_epoch()).count();
    
    launch_init_random_states(
        gpu_data_.d_rand_states,
        static_cast<unsigned long>(seed),
        static_cast<int>(batch_size),
        computation_stream_
    );
    
    cudaError_t err = cudaStreamSynchronize(computation_stream_);
    if (err != cudaSuccess) {
        std::cerr << "Failed to initialize random states: " << cudaGetErrorString(err) << std::endl;
        return false;
    }
    
    return true;
}

bool CudaMotifGenerator::add_keys(const std::vector<std::string>& keys) {
    keys_ = keys;
    encoded_keys_.clear();
    
    // Encode keys for GPU
    for (const auto& key : keys) {
        encoded_keys_.push_back(encode_sequence(key));
    }
    
    return true;
}

std::vector<std::string> CudaMotifGenerator::generate_payloads_batch(size_t batch_size) {
    // Allocate memory if needed
    if (!gpu_data_.is_allocated || gpu_data_.batch_size != batch_size) {
        if (!allocate_gpu_memory(batch_size, constraints_.payload_size)) {
            return {};
        }
    }
    
    // Start timing
    cudaEventRecord(start_event_, computation_stream_);
    
    // Copy constraints and hyperparameters to device
    BiologicalConstraints* d_constraints;
    Hyperparameters* d_hyperparams;
    unsigned char* d_keys;
    
    cudaMalloc(&d_constraints, sizeof(BiologicalConstraints));
    cudaMalloc(&d_hyperparams, sizeof(Hyperparameters));
    
    cudaMemcpy(d_constraints, &constraints_, sizeof(BiologicalConstraints), cudaMemcpyHostToDevice);
    cudaMemcpy(d_hyperparams, &hyperparams_, sizeof(Hyperparameters), cudaMemcpyHostToDevice);
    
    // Copy encoded keys to device
    size_t keys_size = encoded_keys_.size() * constraints_.key_size * sizeof(unsigned char);
    cudaMalloc(&d_keys, keys_size);
    
    // Flatten encoded keys for GPU
    std::vector<unsigned char> flattened_keys;
    for (const auto& key : encoded_keys_) {
        flattened_keys.insert(flattened_keys.end(), key.begin(), key.end());
    }
    cudaMemcpy(d_keys, flattened_keys.data(), keys_size, cudaMemcpyHostToDevice);
    
    // Launch MDP generation kernel
    launch_mdp_generation_kernel(
        gpu_data_.d_sequences,
        gpu_data_.d_rewards,
        gpu_data_.d_probabilities,
        gpu_data_.d_rand_states,
        gpu_data_.d_valid_flags,
        gpu_data_.d_sequence_lengths,
        d_constraints,
        d_hyperparams,
        d_keys,
        static_cast<int>(batch_size),
        constraints_.payload_size,
        computation_stream_
    );
    
    // Launch constraint validation kernel
    launch_constraint_validation_kernel(
        gpu_data_.d_sequences,
        gpu_data_.d_sequence_lengths,
        gpu_data_.d_valid_flags,
        d_constraints,
        d_keys,
        static_cast<int>(batch_size),
        computation_stream_
    );
    
    // Copy results back to host
    cudaMemcpyAsync(gpu_data_.h_valid_flags.data(), gpu_data_.d_valid_flags,
                    batch_size * sizeof(unsigned char), cudaMemcpyDeviceToHost, memory_stream_);
    
    std::vector<unsigned char> h_sequences(batch_size * constraints_.payload_size);
    cudaMemcpyAsync(h_sequences.data(), gpu_data_.d_sequences,
                    batch_size * constraints_.payload_size * sizeof(unsigned char),
                    cudaMemcpyDeviceToHost, memory_stream_);
    
    // Wait for completion
    cudaStreamSynchronize(computation_stream_);
    cudaStreamSynchronize(memory_stream_);
    
    // Stop timing
    cudaEventRecord(stop_event_, computation_stream_);
    cudaEventSynchronize(stop_event_);
    
    float generation_time_ms;
    cudaEventElapsedTime(&generation_time_ms, start_event_, stop_event_);
    perf_metrics_.generation_time_ms += generation_time_ms;
    
    // Process results
    std::vector<std::string> valid_payloads;
    size_t valid_count = 0;
    
    for (size_t i = 0; i < batch_size; i++) {
        if (gpu_data_.h_valid_flags[i] != 0) {  // Check for non-zero instead of bool
            std::vector<unsigned char> sequence(
                h_sequences.begin() + i * constraints_.payload_size,
                h_sequences.begin() + (i + 1) * constraints_.payload_size
            );
            valid_payloads.push_back(decode_sequence(sequence));
            valid_count++;
        }
    }
    
    // Update performance metrics
    perf_metrics_.valid_sequences_generated += valid_count;
    perf_metrics_.total_sequences_attempted += batch_size;
    perf_metrics_.success_rate = static_cast<float>(perf_metrics_.valid_sequences_generated) /
                                perf_metrics_.total_sequences_attempted;
    
    // Cleanup device memory
    cudaFree(d_constraints);
    cudaFree(d_hyperparams);
    cudaFree(d_keys);
    
    return valid_payloads;
}

std::string CudaMotifGenerator::generate_single_payload() {
    auto results = generate_payloads_batch(1);
    return results.empty() ? "" : results[0];
}

std::vector<std::string> CudaMotifGenerator::get_motifs(const std::vector<std::string>& payloads) {
    std::vector<std::string> motifs;
    
    for (const auto& payload : payloads) {
        for (size_t i = 0; i < keys_.size(); i++) {
            // Motif 1: key[i] + payload + key[i]
            std::string motif1 = keys_[i] + payload + keys_[i];
            motifs.push_back(motif1);
            
            // Motif 2: key[i] + payload + key[(i+1) % key_count]
            std::string motif2 = keys_[i] + payload + keys_[(i + 1) % keys_.size()];
            motifs.push_back(motif2);
        }
    }
    
    return motifs;
}

CudaMotifGenerator::PerformanceMetrics CudaMotifGenerator::get_performance_metrics() const {
    return perf_metrics_;
}

void CudaMotifGenerator::reset_performance_metrics() {
    memset(&perf_metrics_, 0, sizeof(PerformanceMetrics));
}

std::vector<unsigned char> CudaMotifGenerator::encode_sequence(const std::string& sequence) {
    std::vector<unsigned char> encoded;
    encoded.reserve(sequence.length());
    
    for (char c : sequence) {
        switch (c) {
            case 'A': case 'a': encoded.push_back(A_IDX); break;
            case 'T': case 't': encoded.push_back(T_IDX); break;
            case 'C': case 'c': encoded.push_back(C_IDX); break;
            case 'G': case 'g': encoded.push_back(G_IDX); break;
            default:
                std::cerr << "Invalid nucleotide: " << c << std::endl;
                encoded.push_back(A_IDX); // Default to A
        }
    }
    
    return encoded;
}

std::string CudaMotifGenerator::decode_sequence(const std::vector<unsigned char>& encoded) {
    std::string sequence;
    sequence.reserve(encoded.size());
    
    const char nucleotides[] = {'A', 'T', 'C', 'G'};
    
    for (unsigned char idx : encoded) {
        if (idx < NUCLEOTIDE_COUNT) {
            sequence += nucleotides[idx];
        } else {
            sequence += 'A'; // Default for invalid indices
        }
    }
    
    return sequence;
}

void CudaMotifGenerator::print_device_info() {
    int device_count;
    cudaGetDeviceCount(&device_count);
    
    std::cout << "=== CUDA Device Information ===" << std::endl;
    std::cout << "Number of CUDA devices: " << device_count << std::endl;
    
    for (int i = 0; i < device_count; i++) {
        cudaDeviceProp prop;
        cudaGetDeviceProperties(&prop, i);
        
        std::cout << "\nDevice " << i << ": " << prop.name << std::endl;
        std::cout << "  Compute Capability: " << prop.major << "." << prop.minor << std::endl;
        std::cout << "  Total Global Memory: " << prop.totalGlobalMem / (1024*1024) << " MB" << std::endl;
        std::cout << "  Max Threads per Block: " << prop.maxThreadsPerBlock << std::endl;
        std::cout << "  Max Grid Size: " << prop.maxGridSize[0] << " x " << prop.maxGridSize[1] 
                  << " x " << prop.maxGridSize[2] << std::endl;
        std::cout << "  Shared Memory per Block: " << prop.sharedMemPerBlock / 1024 << " KB" << std::endl;
        std::cout << "  Warp Size: " << prop.warpSize << std::endl;
        std::cout << "  Memory Clock Rate: " << prop.memoryClockRate / 1000 << " MHz" << std::endl;
        std::cout << "  Memory Bus Width: " << prop.memoryBusWidth << " bits" << std::endl;
    }
}